<?php
/**
 * Created by PhpStorm.
 * User: misch
 * Date: 28.12.2017
 * Time: 18:23
 */
class Progroup_Novaposhta_Model_Observer extends Mage_Core_Model_Abstract{
    /**
     * @param $observer
     */
    public function saveShipping($observer){
        $iOrderId = Mage::getSingleton('checkout/session')->getLastRealOrderId();
        $oOrder = Mage::getModel('sales/order')->loadByIncrementId($iOrderId);
        $oOrder->getShippingDescription();
        $request = $observer->getRequest();
        $pickup = $request->getParam('shipping_novaposhta',false);
        if($pickup){
            Mage::getSingleton('checkout/session')
                ->setArea($pickup['area'])
                ->setCity($pickup['city'])
                ->setWarehouse($pickup['warehouse']);
        }
    }

    /**
     * @param $evt
     * @throws Exception
     */
    public function saveOrderAfter($evt){
        $connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        $order = $evt->getOrder();
        $area = Mage::getSingleton('checkout/session')->getArea();
        $sqlqury ="Select Description FROM novaposhta_areas WHERE ref = '{$area}'";
        $rez_area = $connection->fetchAll($sqlqury);
        $city = Mage::getSingleton('checkout/session')->getCity();
        $sqlqury_city ="Select Description FROM novaposhta_cities WHERE Ref = '{$city}'";
        $rez_city = $connection->fetchAll($sqlqury_city);
        $warehouse = Mage::getSingleton('checkout/session')->getWarehouse();
        $sqlqury_ware ="Select Description FROM novaposhta_warehouses WHERE Ref = '{$warehouse}'";
        $rez_warehouse = $connection->fetchAll($sqlqury_ware);
        $pickupModel = Mage::getModel('novaposhta/order');
            $pickupModel->setOrderId($order->getId());
            $pickupModel->setArea($rez_area[0]['Description']);
            $pickupModel->setCity($rez_city[0]['Description']);
            $pickupModel->setWarehouse($rez_warehouse[0]['Description']);
            $pickupModel->save();
    }

    /**
     * @param $evt
     * @throws Exception
     */
    public function saveQuoteAfter($evt){
        $quote = $evt->getQuote();
        $connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        $area = Mage::getSingleton('checkout/session')->getArea();
        $sqlqury ="Select Description FROM novaposhta_areas WHERE ref = '{$area}'";
        $rez_area = $connection->fetchAll($sqlqury);
        $city = Mage::getSingleton('checkout/session')->getCity();
        $sqlqury_city ="Select Description FROM novaposhta_cities WHERE Ref = '{$city}'";
        $rez_city = $connection->fetchAll($sqlqury_city);
        $warehouse = Mage::getSingleton('checkout/session')->getWarehouse();
        $sqlqury_ware ="Select Description FROM novaposhta_warehouses WHERE Ref = '{$warehouse}'";
        $rez_warehouse = $connection->fetchAll($sqlqury_ware);
        if (!empty($area) && !empty($city) && !empty($warehouse)) {
            $pickupModel = Mage::getModel('novaposhta/quote');
            $pickupModel->setQuoteId($quote->getId());
            $pickupModel->setArea($rez_area[0]['Description']);
            $pickupModel->setCity($rez_city[0]['Description']);
            $pickupModel->setWarehouse($rez_warehouse[0]['Description']);
            $pickupModel->save();
        }
    }
}