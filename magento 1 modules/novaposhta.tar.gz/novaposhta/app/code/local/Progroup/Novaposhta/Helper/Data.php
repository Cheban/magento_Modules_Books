<?php
class Progroup_Novaposhta_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function getStoreConfig($key)
    {
        return Mage::getStoreConfig('carriers/novaposhta/' . $key);
    }
}
	 