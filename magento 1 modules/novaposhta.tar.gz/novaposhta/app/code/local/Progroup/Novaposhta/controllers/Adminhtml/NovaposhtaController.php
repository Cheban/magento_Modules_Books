<?php
class Progroup_Novaposhta_Adminhtml_NovaposhtaController extends Mage_Adminhtml_Controller_Action
{

    public function citiesAction(){
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function warehousesAction(){
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function areasAction(){
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function updateCitiesAction(){
        try {
            $resource = Mage::getSingleton('core/resource');
            $write = $resource->getConnection('core_write');
            $table_cities = $resource->getTableName('novaposhta_cities');
            $write->truncateTable($table_cities);
            $cities = Mage::getSingleton('novaposhta/api_api2')->getCities();
            foreach ($cities['data'] as $item) {
                $model = Mage::getModel('novaposhta/cities');

                $model->setData(array(
                    'Description' => $item['Description'],
                    'DescriptionRu' => $item['DescriptionRu'],
                    'Ref' => $item['Ref'],
                    'Delivery1' => $item['Delivery1'],
                    'Area' => $item['Area'],
                    'CityID' => $item['CityID'],
                ))->save();
            }
            Mage::getSingleton('core/session')->addSuccess('Cities was update.');
            $this->_redirect('*/*/cities');
        } catch (Exception $e) {
            Mage::getSingleton('core/session')->addError('Cities was not update.');
            $this->_redirect('*/*/cities');
        }
    }
    
    public function updateAreasAction(){
        try {
            $resource = Mage::getSingleton('core/resource');
            $write = $resource->getConnection('core_write');
            $table_areas = $resource->getTableName('novaposhta_areas');
            $write->truncateTable($table_areas);
            $areas = Mage::getSingleton('novaposhta/api_api2')->getAreas();
            foreach ($areas['data'] as $item) {
                $model = Mage::getModel('novaposhta/areas');
                $model->setData(array(
                    'description'       => $item['Description'],
                    'areas_center'     => $item['AreasCenter'],
                    'ref'               => $item['Ref'],
                ))->save();
            }
            Mage::getSingleton('core/session')->addSuccess('Areas was update.');
            $this->_redirect('*/*/areas');
        } catch (Exception $e) {
            Mage::getSingleton('core/session')->addError('Areas was not update.');
            $this->_redirect('*/*/areas');
        }
    }
    
    public function updateWarehousesAction(){
        try {
            $resource = Mage::getSingleton('core/resource');
            $write = $resource->getConnection('core_write');
            $table_warehouses = $resource->getTableName('novaposhta_warehouses');
            $write->truncateTable($table_warehouses);
            $warehouses = Mage::getSingleton('novaposhta/api_api2')->getWarehouses();
            foreach ($warehouses['data'] as $item) {
                $model = Mage::getModel('novaposhta/warehouses');
                $model->setData(array(
                    'SiteKey'           => $item['SiteKey'],
                    'Description'       => $item['Description'],
                    'DescriptionRu'     => $item['DescriptionRu'],
                    'Phone'             => $item['Phone'],
                    'TypeOfWarehouse'   => $item['TypeOfWarehouse'],
                    'Ref'               => $item['Ref'],
                    'Number'            => $item['Number'],
                    'CityRef'           => $item['CityRef'],
                    'CityDescription'   => $item['CityDescription'],
                    'CityDescriptionRu' => $item['CityDescriptionRu'],
                ))->save();
            }
            Mage::getSingleton('core/session')->addSuccess('Warehouses was update.');
            $this->_redirect('*/*/warehouses');
        } catch (Exception $e) {
            Mage::getSingleton('core/session')->addError('Warehouses was not update.');
            $this->_redirect('*/*/warehouses');
        }
    }
}