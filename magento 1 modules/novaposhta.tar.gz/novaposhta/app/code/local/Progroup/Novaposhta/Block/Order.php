<?php
class Progroup_Novaposhta_Block_Order extends Mage_Core_Block_Template{
    /**
     * @return mixed order data
     */
    public function getCustomData(){
        $model = Mage::getModel('novaposhta/order');
        return $model->getByOrder($this->getOrder()->getId());
    }

    /**
     * @return mixed current order
     */
    public function getOrder()
    {
        return Mage::registry('current_order');
    }

    /**
     * @return mixed selected sity
     */
    public function getSelectCity(){
        $connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        $city = Mage::getSingleton('checkout/session')->getCity();
        $sqlquery_city ="Select Description FROM novaposhta_cities WHERE Ref = '{$city}'";
        $rez_city = $connection->fetchAll($sqlquery_city);

        return $rez_city;
    }

    /**
     * @return mixed selected area
     */
    public function getSelectArea()
    {
        $connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        $area = Mage::getSingleton('checkout/session')->getArea();
        $sqlquery ="Select Description FROM novaposhta_areas WHERE ref = '{$area}'";
        $rez_area = $connection->fetchAll($sqlquery);

        return $rez_area;
    }

    /**
     * @return mixed selected warehouse
     */
    public function getSelectWarehouse()
    {
        $connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        $warehouse = Mage::getSingleton('checkout/session')->getWarehouse();
        $sqlquery_ware ="Select Description FROM novaposhta_warehouses WHERE Ref = '{$warehouse}'";
        $rez_warehouse = $connection->fetchAll($sqlquery_ware);

        return $rez_warehouse;
    }
}