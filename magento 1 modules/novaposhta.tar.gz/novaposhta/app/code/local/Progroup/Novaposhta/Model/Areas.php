<?php
/**
 * Created by PhpStorm.
 * User: misch
 * Date: 12.01.2018
 * Time: 13:41
 */
class Progroup_Novaposhta_Model_Areas extends Mage_Core_Model_Abstract
{
    protected function _construct(){

        $this->_init("novaposhta/areas");

    }

}
