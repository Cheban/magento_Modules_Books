function getCityIfLoginOpenMap(dataArea) {
    jQuery(".ware_desc").hide();
    var area = dataArea.value;
    jQuery.ajax({
        type: "POST",
        url:STORE_URL+"novaposhta/ajax/getArea/",
        data: {'area_ref': area},
        dataType: "json",
        success: function (data) {
            if (data.cities == null) {
                jQuery(".city_desc").html("");
                var li_class = jQuery('' +
                    '<span class="input-box">' +
                    '<select class="cities" name="shipping_novaposhta[city]" onchange="getWarehouseIfLoginOpenMap(this)"> ' +
                    '<option>Доставка в дану область недоступна!</option>' +
                    '</select>' + '</span>');
                li_class.appendTo('.city_desc');
            }else {
            jQuery(".city_desc").html("");
            var li_class = jQuery('' +
                '<span class="input-box">' +
                '<select class="cities" name="shipping_novaposhta[city]" onchange="getWarehouseIfLoginOpenMap(this)"> ' +
                '<option>Виберіть місто..</option>' +
                '</select>' + '</span>');
            li_class.appendTo('.city_desc');

            jQuery.each(data.cities, function (index, value) {
                var select_class = jQuery(
                    '<option value=' + value['Ref'] + '>' + value['Description'] +
                    '</option>'
                );
                select_class.appendTo('.cities');
            });
        }
        var area = jQuery('.area_desc select option:selected').text();
            jQuery('input[name="billing[region]"]').val(area);
        }
    });
}
function getWarehouseIfLoginOpenMap(dataCity) {
    var city = dataCity.value;
    jQuery.ajax({
        type: "POST",
        url:STORE_URL+"/novaposhta/ajax/getCity/",
        data: {'city_name': city},
        dataType: "json",
        success: function (data) {
            jQuery(".ware_desc").show();
            jQuery(".ware_desc").html("");
            var li_class = jQuery('' +
                '<select class="warehouses" name="shipping_novaposhta[warehouse]" onchange="getWarehouse(this)"> ' +
                '<option>Виберіть відділення..</option>'+
                '</select>');
            li_class.appendTo('.ware_desc');

            jQuery.each(data.warehouses, function (index,value) {
                var select_class = jQuery(
                    '<option value=' + value['Ref'] + '>'+ value['Description'] +
                    '</option>'
                );
                select_class.appendTo('.warehouses');
            });

            var city = jQuery('.city_desc select option:selected').text();
            jQuery('input[name="billing[city]"]').val(city);
        }
    });
}
function getWarehouse(dataCity) {
    setTimeout(function () {
        var address = jQuery('.ware_desc select option:selected').text();
        jQuery('input.streat_one').val(address);
    },500);
}

